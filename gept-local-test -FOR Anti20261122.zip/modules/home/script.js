export default {
    id: "home",
    
    init: async function(container) {
        container.innerHTML = `
            <div style="max-width: 900px; margin: 0 auto; padding: 10px;">
                <div style="text-align: center; margin-bottom: 30px;">
                    <h1 data-theme-copy="home.title" style="color: #38bdf8; font-size: 1.8rem; margin-bottom: 10px;">歡迎回到學習大廳！</h1>
                    <p data-theme-copy="home.subtitle" style="color: #94a3b8; font-size: 1rem;">請選擇您今天要挑戰的英語學習單元：</p>
                </div>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
                    
                    <!-- 功能 1：核心單字選擇題 -->
                    <div class="lobby-card" data-target="vocabulary" style="background: #1e293b; border: 1px solid #334155; padding: 25px; border-radius: 12px; cursor: pointer; transition: transform 0.2s, border-color 0.2s;">
                        <div style="font-size: 2rem; margin-bottom: 10px;">🎯</div>
                        <h3 data-theme-copy="unit.vocab.title" style="color: #f8fafc; margin-bottom: 8px; font-size: 1.2rem;">1. 核心單字選擇題</h3>
                        <p style="color: #94a3b8; font-size: 0.9rem; line-height: 1.5;">經典四選一測驗，透過中翻英與英翻中快速累積字彙量。</p>
                    </div>

                    <!-- 功能 2：生活情境句子選擇題 -->
                    <div class="lobby-card" data-target="sentences" style="background: #1e293b; border: 1px solid #334155; padding: 25px; border-radius: 12px; cursor: pointer; transition: transform 0.2s, border-color 0.2s;">
                        <div style="font-size: 2rem; margin-bottom: 10px;">💬</div>
                        <h3 data-theme-copy="unit.sentences.title" style="color: #f8fafc; margin-bottom: 8px; font-size: 1.2rem;">2. 生活情境句子選擇題</h3>
                        <p style="color: #94a3b8; font-size: 0.9rem; line-height: 1.5;">智慧同詞性干擾項，透過真實情境對話提升應對能力。</p>
                    </div>

                    <!-- 功能 3：智慧克漏字填充 -->
                    <div class="lobby-card" data-target="cloze" style="background: #1e293b; border: 1px solid #334155; padding: 25px; border-radius: 12px; cursor: pointer; transition: transform 0.2s, border-color 0.2s;">
                        <div style="font-size: 2rem; margin-bottom: 10px;">✍️</div>
                        <h3 data-theme-copy="unit.cloze.title" style="color: #f8fafc; margin-bottom: 8px; font-size: 1.2rem;">3. 智慧克漏字填充</h3>
                        <p style="color: #94a3b8; font-size: 0.9rem; line-height: 1.5;">結合單字專屬例句挖空填空，強化拼字與文法結構。</p>
                    </div>

                    <!-- 功能 4：閱讀測驗專區 -->
                    <div class="lobby-card" data-target="reading" style="background: #1e293b; border: 1px solid #334155; padding: 25px; border-radius: 12px; cursor: pointer; transition: transform 0.2s, border-color 0.2s;">
                        <div style="font-size: 2rem; margin-bottom: 10px;">📖</div>
                        <h3 data-theme-copy="unit.reading.title" style="color: #f8fafc; margin-bottom: 8px; font-size: 1.2rem;">4. 閱讀測驗專區</h3>
                        <p style="color: #94a3b8; font-size: 0.9rem; line-height: 1.5;">多層級閱讀短文與精準題組，全面提升長文理解力。</p>
                    </div>

                </div>
            </div>
        `;

        // 幫所有卡片加上點擊切換事件
        container.querySelectorAll(".lobby-card").forEach(card => {
            card.addEventListener("mouseenter", () => {
                card.style.transform = "translateY(-4px)";
                card.style.borderColor = "#38bdf8";
            });
            card.addEventListener("mouseleave", () => {
                card.style.transform = "translateY(0)";
                card.style.borderColor = "#334155";
            });

            card.addEventListener("click", () => {
                const targetModule = card.getAttribute("data-target");
                // 透過修改 Hash 或呼叫全域路由切換頁面
                window.location.hash = targetModule;
            });
        });
    },

    destroy: function() {
        console.log("Home module destroyed.");
    }
};